# Play Store metadata automation (optional)

Push your Play Console listing text and images from files in your repo
instead of clicking through Play Console by hand every time you update
your description or swap a screenshot. This is entirely separate from
your build/sign/upload pipeline (`android-build.yml`) — that's untouched,
and this never touches your APK/AAB or any release track.

Skip this whole feature if you're happy updating your store listing
manually — it's optional, and there's no cost to ignoring it.

## What you need

Uses [fastlane](https://fastlane.tools) under the hood, run as a GitHub
Actions workflow (fastlane itself, and the credentials it needs, live
only in CI — you don't need Ruby or fastlane installed locally).

1. Copy `fastlane/Fastfile` and `fastlane/Gemfile` from this template
   into your repo's `fastlane/` folder.
2. Copy `.github/workflows/playstore-metadata.yml` into your own
   `.github/workflows/`.
3. Create your real metadata content (next section) — the workflow fails
   fast with a clear message if this is missing, rather than doing
   nothing silently.
4. Push, then run the workflow by hand from the Actions tab
   (`workflow_dispatch` — this doesn't run on every push, since a
   listing update is something you do occasionally, not every commit).

## fastlane/metadata/android/

```
fastlane/metadata/android/en-US/
  title.txt
  short_description.txt
  full_description.txt
  changelogs/
    default.txt
  images/
    icon.png
    featureGraphic.png
    phoneScreenshots/
      01_home.png
      02_feature.png
```

Uses the same `ANDROID_PLAY_SERVICE_ACCOUNT_JSON` secret and
`ANDROID_PACKAGE_NAME` variable you already set up in ANDROID.md for the
Play Store upload step — nothing extra to configure in Play Console.

`fastlane android push_metadata` uses `skip_upload_apk: true` and
`skip_upload_aab: true` — it never touches your binary or any release
track. Tick "Dry run" when triggering the workflow (`validate_only`) to
check everything without actually publishing a change, useful the first
time you run this against a real listing.

## Status

Built and reviewed against fastlane's current (August 2026) `supply`
documentation. Not yet live-tested against a real Play Console listing —
treat as audited, not proven, until you've run it once yourself (ideally
with `validate_only` on first) against your own listing.
