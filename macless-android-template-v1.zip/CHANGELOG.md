# Changelog

What's changed in this template since you bought it. There's no
automated update notification yet — the most reliable way to check is
comparing this file's dates against when you last downloaded.

This is the Android-only cut of the full Macless template — everything
here is drawn from the same pipeline, same live-tests, same real bugs
found and fixed. See the full template's own CHANGELOG.md (linked from
the site) for iOS-side history that doesn't apply to this package.

## 2026-08-19

- **New: automated keystore expiry monitoring** —
  `.github/workflows/check-expiry.yml`, a weekly scheduled workflow (also
  runnable on demand) that checks your `ANDROID_KEYSTORE_BASE64` secret
  and pings your existing `NOTIFY_WEBHOOK_URL` webhook only when the
  signing key inside is actually expiring or expired — silent the rest
  of the time. A full report always lands in that run's Summary tab
  regardless.
- **New: `scripts/generate_signing_secrets.sh`**, a guided setup wizard
  for the whole one-time keystore setup — walks through generating a
  new keystore or pointing at an existing one, and if you have the
  [GitHub CLI](https://cli.github.com) (`gh`) installed and logged in,
  offers to push the resulting secrets straight into your repo's
  Settings instead of you copy-pasting them into the GitHub web UI.
  Ends by offering to run Signing Doctor against exactly what it just
  generated, so you find out immediately if something's off.
- **[Signing Doctor](https://github.com/jackson26-source/macless-signing-doctor)
  now checks Android keystores** (see ANDROID.md) — whether it opens
  with your password/alias, whether the signing key is expiring, and
  flags an older SHA1-based signature algorithm. Vendored into this
  product as `scripts/signing-doctor.sh` (used by `check-expiry.yml`
  above).

## 2026-08-18 (2)

- **Legibility pass on the docs.** README.md and ANDROID.md now define
  their core jargon in plain language the first time it's used (GitHub
  Actions, Android App Bundle, keystore, service account, package name)
  instead of assuming you already know it. No instructions changed — same
  steps, same order, just easier to follow the first time through if
  you're newer to this. SUPPORT.md, TESTING.md, and STORE_METADATA.md were
  left as-is since they're already written for someone actively debugging
  or editing a workflow file, where precise technical terms matter more
  than a plain-language gloss.

## 2026-08-18

- Initial release of the Android-only template: `android-build.yml`
  (build + sign a Play-Store-ready `.aab`), `playstore-metadata.yml` +
  `fastlane/` (optional listing automation), `ANDROID.md`,
  `STORE_METADATA.md`, `TESTING.md`.
- `android-build.yml` build+sign steps are live-tested and proven (three
  real bugs found and fixed along the way — see ANDROID.md's Status
  section). The final Google Play upload step and
  `playstore-metadata.yml` are audited, not yet live-tested against a
  real Play Console account.
