# Changelog

What's changed in this template since you bought it. There's no
automated update notification yet — the most reliable way to check is
comparing this file's dates against when you last downloaded.

This is the Android-only cut of the full Macless template — everything
here is drawn from the same pipeline, same live-tests, same real bugs
found and fixed. See the full template's own CHANGELOG.md (linked from
the site) for iOS-side history that doesn't apply to this package.

## 2026-08-18 (2)

- **Legibility pass on the docs.** README.md and ANDROID.md now define
  their core jargon in plain language the first time it's used (GitHub
  Actions, Android App Bundle, keystore, service account, package name)
  instead of assuming you already know it. No instructions changed — same
  steps, same order, just easier to follow the first time through if
  you're newer to this. SUPPORT.md, TESTING.md, and STORE_METADATA.md were
  left as-is since they're already written for someone actively debugging
  or editing a workflow file, where precise technical terms matter more
  than a plain-language gloss.

## 2026-08-18

- Initial release of the Android-only template: `android-build.yml`
  (build + sign a Play-Store-ready `.aab`), `playstore-metadata.yml` +
  `fastlane/` (optional listing automation), `ANDROID.md`,
  `STORE_METADATA.md`, `TESTING.md`.
- `android-build.yml` build+sign steps are live-tested and proven (three
  real bugs found and fixed along the way — see ANDROID.md's Status
  section). The final Google Play upload step and
  `playstore-metadata.yml` are audited, not yet live-tested against a
  real Play Console account.
