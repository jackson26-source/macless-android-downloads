# Changelog

What's changed in this template since you bought it. There's no
automated update notification yet — the most reliable way to check is
comparing this file's dates against when you last downloaded.

This is the Android-only cut of the full Macless template — everything
here is drawn from the same pipeline, same live-tests, same real bugs
found and fixed. See the full template's own CHANGELOG.md (linked from
the site) for iOS-side history that doesn't apply to this package.

## 2026-08-18

- Initial release of the Android-only template: `android-build.yml`
  (build + sign a Play-Store-ready `.aab`), `playstore-metadata.yml` +
  `fastlane/` (optional listing automation), `ANDROID.md`,
  `STORE_METADATA.md`, `TESTING.md`.
- `android-build.yml` build+sign steps are live-tested and proven (three
  real bugs found and fixed along the way — see ANDROID.md's Status
  section). The final Google Play upload step and
  `playstore-metadata.yml` are audited, not yet live-tested against a
  real Play Console account.
