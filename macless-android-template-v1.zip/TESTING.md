# Testing a workflow change before you trust it

Static review — reading the YAML carefully — is not the same as knowing
a workflow actually works. This template's own `android-build.yml` is a
real example: it passed careful review and still shipped with three
separate bugs (a missing `@capacitor/android` install, a peer-dependency
version mismatch, and a JDK 17-vs-21 mismatch) that only an actual run on
a real GitHub Actions runner caught — see ANDROID.md's "Status" section
for the full story.

Worth repeating any time you change the workflow file yourself — not
just before trusting a change in your own project, but especially before
telling anyone else it works.

## 1. Spin up a throwaway scaffold

You don't need your real app for this — a minimal Capacitor project is
enough: a `package.json` with the Capacitor deps, a
`capacitor.config.json` with any `appId`/`appName`, and a placeholder
`www/index.html`.

Push it to a new repo — public is simplest and it doesn't need to go
anywhere near your real app or its signing secrets.

## 2. Copy in `android-build.yml`

Same path as your real project: `.github/workflows/android-build.yml`.

## 3. Use a disposable test keystore, not your real one

`keytool -genkey -v -keystore test.keystore -alias upload -keyalg RSA
-keysize 2048 -validity 10000` generates one in seconds — there's no
reason to risk your real signing keystore in a throwaway test repo. The
final "Upload to Google Play" step will fail without a real Play Console
service account, which is expected — you're testing the build+sign
steps, not the upload.

## 4. Check the actual artifact, not just the green checkmark

A workflow can show green and still have produced nothing useful.
Download the `.aab` artifact and confirm it's actually there and
non-empty, not just that the step didn't print an error.

## 5. Clean up

Delete the throwaway repo when you're done, or make it private if GitHub
won't let you delete it right away. Don't leave real signing secrets
sitting in a throwaway repo any longer than the test takes.
