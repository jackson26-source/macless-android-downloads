#!/usr/bin/env bash
#
# Guided setup wizard for this Android-only Macless template. Walks
# through the copy-paste-heavy parts of ANDROID.md interactively,
# generates the exact base64 value you need as a GitHub Secret, and —
# if you have the GitHub CLI (`gh`) installed and logged in — can push
# it straight into your repo's Settings > Secrets/Variables for you,
# instead of you copy-pasting it by hand.
#
# It doesn't touch your Google account beyond what you do yourself in
# a browser at their prompting (creating the Play Console app or
# service account) — this script handles the command-line half
# (keytool/openssl/base64) before and after that, and optionally the
# "paste into GitHub" half too.
#
# Ends by offering to run Signing Doctor (macless-signing-doctor,
# free/standalone: https://github.com/jackson26-source/macless-signing-doctor)
# against exactly what was just generated, so you find out immediately
# if something's wrong — instead of only discovering it when a real
# build fails later.
#
# Works on macOS and Linux out of the box. On Windows, run it through
# Git Bash (same as the manual keytool/openssl commands in ANDROID.md).
#
# (This is the Android-only cut of the wizard — if you bought the full
# iOS+Android template instead, use the wizard that ships with that
# one, which also covers the iOS/SIGNING.md side.)
#
set -euo pipefail

OUT_DIR="secrets_output"
mkdir -p "$OUT_DIR"
if [ ! -f "$OUT_DIR/.gitignore" ]; then
  echo "*" > "$OUT_DIR/.gitignore"
fi

say() { printf '\n\033[1m%s\033[0m\n' "$1"; }

# Collected along the way; used by the optional gh-push and
# self-verify steps at the end.
ANDROID_KEYSTORE_BASE64_VAL=""
ANDROID_KEYSTORE_PASSWORD_VAL=""
ANDROID_KEY_ALIAS_VAL=""
ANDROID_KEY_PASSWORD_VAL=""
ANDROID_KEYSTORE_RAW_PATH=""

say "== Macless Android setup wizard =="
echo "This writes files into ./$OUT_DIR/ — it's already gitignored, but"
echo "don't commit or share that folder anyway; it will contain a real"
echo "signing keystore in base64 form."

say "Release keystore (ANDROID.md step 1)"
if ! command -v keytool >/dev/null 2>&1; then
  echo "keytool isn't available here (it ships with any JDK). Install a JDK,"
  echo "or generate the keystore on another machine/a GitHub Actions runner"
  echo "and come back to this script with the file path — skipping keystore"
  echo "generation for now."
  read -r -p "Path to an existing release.keystore, if you already have one (blank to skip): " EXISTING_KEYSTORE
  if [ -n "$EXISTING_KEYSTORE" ]; then
    read -r -s -p "Keystore password: " ANDROID_KS_PASSWORD; echo
    read -r -p "Key alias [upload]: " ANDROID_ALIAS
    ANDROID_ALIAS="${ANDROID_ALIAS:-upload}"
    openssl base64 -in "$EXISTING_KEYSTORE" -out "$OUT_DIR/ANDROID_KEYSTORE_BASE64.txt" -A
    ANDROID_KEYSTORE_BASE64_VAL="$OUT_DIR/ANDROID_KEYSTORE_BASE64.txt"
    ANDROID_KEYSTORE_PASSWORD_VAL="$ANDROID_KS_PASSWORD"
    ANDROID_KEY_ALIAS_VAL="$ANDROID_ALIAS"
    ANDROID_KEY_PASSWORD_VAL="$ANDROID_KS_PASSWORD"
    ANDROID_KEYSTORE_RAW_PATH="$EXISTING_KEYSTORE"
    echo "Wrote $OUT_DIR/ANDROID_KEYSTORE_BASE64.txt -> paste as secret ANDROID_KEYSTORE_BASE64"
  fi
else
  echo "Already have a release.keystore from a previous setup? [y/N]"
  read -r -p "> " HAVE_EXISTING
  if [[ "$HAVE_EXISTING" =~ ^[Yy] ]]; then
    read -r -p "Path to it: " ANDROID_KEYSTORE_PATH
    read -r -s -p "Keystore password: " ANDROID_KS_PASSWORD; echo
    read -r -p "Key alias [upload]: " ANDROID_ALIAS
    ANDROID_ALIAS="${ANDROID_ALIAS:-upload}"
  else
    echo "Generating a new one — keep the resulting file safe: if you lose it,"
    echo "you lose the ability to publish updates to this app on Google Play."
    read -r -p "Key alias [upload]: " ANDROID_ALIAS
    ANDROID_ALIAS="${ANDROID_ALIAS:-upload}"
    read -r -p "Your name or company (goes on the keystore's self-signed certificate, Play doesn't show this to users): " ANDROID_DN_NAME
    ANDROID_DN_NAME="${ANDROID_DN_NAME:-Unknown}"
    read -r -s -p "Pick a keystore password (you'll need this again as ANDROID_KEYSTORE_PASSWORD): " ANDROID_KS_PASSWORD; echo
    ANDROID_KEYSTORE_PATH="$OUT_DIR/release.keystore"
    # -dname avoids keytool's own separate interactive name/org/city/etc.
    # prompt sequence, which would otherwise nest inside this script's
    # prompts and can loop/fail under piped or scripted input.
    keytool -genkeypair -v -keystore "$ANDROID_KEYSTORE_PATH" -alias "$ANDROID_ALIAS" \
      -keyalg RSA -keysize 2048 -validity 10000 \
      -dname "CN=$ANDROID_DN_NAME, OU=Unknown, O=Unknown, L=Unknown, ST=Unknown, C=US" \
      -storepass "$ANDROID_KS_PASSWORD" -keypass "$ANDROID_KS_PASSWORD"
    echo "Wrote $ANDROID_KEYSTORE_PATH"
  fi

  openssl base64 -in "$ANDROID_KEYSTORE_PATH" -out "$OUT_DIR/ANDROID_KEYSTORE_BASE64.txt" -A
  echo "Wrote $OUT_DIR/ANDROID_KEYSTORE_BASE64.txt -> paste as secret ANDROID_KEYSTORE_BASE64"
  ANDROID_KEYSTORE_BASE64_VAL="$OUT_DIR/ANDROID_KEYSTORE_BASE64.txt"
  ANDROID_KEYSTORE_PASSWORD_VAL="$ANDROID_KS_PASSWORD"
  ANDROID_KEY_ALIAS_VAL="$ANDROID_ALIAS"
  ANDROID_KEY_PASSWORD_VAL="$ANDROID_KS_PASSWORD"
  ANDROID_KEYSTORE_RAW_PATH="$ANDROID_KEYSTORE_PATH"
fi

echo
echo "(ANDROID_KEY_PASSWORD -> same as ANDROID_KEYSTORE_PASSWORD unless you"
echo "used a different key password when originally generating this keystore."
echo "ANDROID_PLAY_SERVICE_ACCOUNT_JSON is a separate step — see ANDROID.md"
echo "section 3, it's a file you download from Google Play Console, this"
echo "script doesn't touch Google Play.)"

# =======================================================================
# Summary
# =======================================================================
say "Done. Summary of what to paste into GitHub -> Settings -> Secrets and variables -> Actions:"

cat <<SUMMARY

Repository secrets:
  ANDROID_KEYSTORE_BASE64         -> contents of $ANDROID_KEYSTORE_BASE64_VAL
  ANDROID_KEYSTORE_PASSWORD       -> the password you set above (not saved to a file)
  ANDROID_KEY_ALIAS               -> $ANDROID_KEY_ALIAS_VAL
  ANDROID_KEY_PASSWORD            -> same as above unless you used a different one
  ANDROID_PLAY_SERVICE_ACCOUNT_JSON -> separate step, see ANDROID.md section 3
SUMMARY

echo
echo "Everything under $OUT_DIR/ is gitignored. Delete that folder once"
echo "you've pasted these into GitHub (or had this script push them for you"
echo "below) — there's no reason to keep plaintext copies of your signing"
echo "secrets sitting on disk longer than that."

# =======================================================================
# Optional: push straight to GitHub via the gh CLI
# =======================================================================
say "Push these directly to your GitHub repo now?"
if [ -z "$ANDROID_KEYSTORE_BASE64_VAL" ]; then
  echo "Nothing was generated this run (keystore step was skipped) — nothing to push."
elif ! command -v gh >/dev/null 2>&1; then
  echo "The GitHub CLI ('gh') isn't installed here, so this step is skipped —"
  echo "install it from cli.github.com if you'd rather not paste each value"
  echo "into the GitHub web UI by hand next time. For now, paste the values"
  echo "above into your repo's Settings -> Secrets and variables -> Actions."
elif ! gh auth status >/dev/null 2>&1; then
  echo "'gh' is installed but not logged in ('gh auth login' first) — skipping."
  echo "Paste the values above into Settings -> Secrets and variables -> Actions"
  echo "for now."
else
  DETECTED_REPO=""
  if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    DETECTED_REPO=$(gh repo view --json nameWithOwner -q .nameWithOwner 2>/dev/null || echo "")
  fi
  if [ -n "$DETECTED_REPO" ]; then
    read -r -p "Push to $DETECTED_REPO? [Y/n]: " CONFIRM_REPO
    if [[ "$CONFIRM_REPO" =~ ^[Nn] ]]; then
      read -r -p "Repo to push to instead (owner/repo): " TARGET_REPO
    else
      TARGET_REPO="$DETECTED_REPO"
    fi
  else
    read -r -p "Repo to push to (owner/repo): " TARGET_REPO
  fi

  if [ -n "$TARGET_REPO" ]; then
    echo "Pushing to $TARGET_REPO ..."
    gh secret set ANDROID_KEYSTORE_BASE64 --repo "$TARGET_REPO" < "$ANDROID_KEYSTORE_BASE64_VAL"
    printf '%s' "$ANDROID_KEYSTORE_PASSWORD_VAL" | gh secret set ANDROID_KEYSTORE_PASSWORD --repo "$TARGET_REPO"
    printf '%s' "$ANDROID_KEY_ALIAS_VAL" | gh secret set ANDROID_KEY_ALIAS --repo "$TARGET_REPO"
    printf '%s' "$ANDROID_KEY_PASSWORD_VAL" | gh secret set ANDROID_KEY_PASSWORD --repo "$TARGET_REPO"
    echo "Secrets pushed. (ANDROID_PLAY_SERVICE_ACCOUNT_JSON is still a manual"
    echo "step — see ANDROID.md section 3.)"
    echo "Done — check $TARGET_REPO's Settings > Secrets and variables > Actions to confirm."
  else
    echo "No repo given, skipping the push."
  fi
fi

# =======================================================================
# Optional: self-verify with Signing Doctor
# =======================================================================
say "Verify what was just generated with Signing Doctor?"
if [ -z "$ANDROID_KEYSTORE_RAW_PATH" ]; then
  echo "Nothing was generated this run (keystore step was skipped) — nothing to verify."
else
  echo "Signing Doctor (free, standalone: github.com/jackson26-source/macless-signing-doctor)"
  echo "decodes exactly what you just made and tells you in plain English if"
  echo "anything's off, before you find out the hard way in a real build."
  read -r -p "Run it now? [Y/n]: " RUN_DOCTOR
  if ! [[ "$RUN_DOCTOR" =~ ^[Nn] ]]; then
    DOCTOR_SCRIPT="$OUT_DIR/signing-doctor.sh"
    if command -v curl >/dev/null 2>&1 && curl -fsSL \
        "https://raw.githubusercontent.com/jackson26-source/macless-signing-doctor/main/signing-doctor.sh" \
        -o "$DOCTOR_SCRIPT" 2>/dev/null; then
      chmod +x "$DOCTOR_SCRIPT"
      "$DOCTOR_SCRIPT" --android-keystore "$ANDROID_KEYSTORE_RAW_PATH" \
        --android-keystore-password "$ANDROID_KEYSTORE_PASSWORD_VAL" \
        --android-key-alias "$ANDROID_KEY_ALIAS_VAL" \
        || echo "(Signing Doctor found something to fix above — everything it printed still applies even though this wizard already finished.)"
    else
      echo "Couldn't download Signing Doctor (no internet access from here, or"
      echo "github.com is unreachable) — you can run it yourself later:"
      echo "  curl -fsSL https://raw.githubusercontent.com/jackson26-source/macless-signing-doctor/main/signing-doctor.sh -o signing-doctor.sh"
    fi
  fi
fi

say "All done."
