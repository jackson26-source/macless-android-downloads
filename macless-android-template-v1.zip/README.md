# Ship an Android app without a monthly CI bill

A working automated build pipeline — built on GitHub Actions, GitHub's own
free build servers — that builds, signs, and uploads an Android App
Bundle (the packaged, signed file Google Play expects, a `.aab`) to
Google Play. No Codemagic, Bitrise, or Xcode-Cloud-style monthly
subscription; no Mac needed either (Android builds never required one) —
just a one-time setup and a workflow file you own.

This is the cheaper, Android-only cut of [Macless](https://macless.dev)'s
full iOS+Android template — same real pipeline, same
live-tested-not-just-reviewed standard, without the iOS-specific pieces
(SIGNING.md's Apple certificate setup, the three iOS build variants) you
don't need if you're Android-only.

**Already building for iOS too?** The full [Macless](https://macless.dev)
template includes this plus the iOS/TestFlight pipeline (Capacitor, bare
React Native, or Flutter) for one combined price — worth it if you need
both platforms.

## Start here

1. Follow **ANDROID.md** — one-time signing setup (a keystore + a Play
   Console service account), no Android Studio required.
2. Copy `.github/workflows/android-build.yml` into your own repo.
3. Push. Watch the Actions tab.
4. Stuck? See ANDROID.md's own "Status" section for the real bugs this
   pipeline has already hit and fixed, then **SUPPORT.md**.

**Tired of updating your Play Store listing by hand?**
`.github/workflows/playstore-metadata.yml` (see STORE_METADATA.md) pushes
your description and screenshots from files in your repo using fastlane,
reusing the same service account you already set up in step 1. Optional
— skip it if you're happy updating listings by hand.

## Last verified working

| Workflow file | Last live-tested | Status |
|---|---|---|
| `android-build.yml` | 2026-08-18 | Proven for build + sign; the final Google Play upload step is still audited only, pending a live-tested Play Console service account |
| `playstore-metadata.yml` | — | Audited against fastlane's current docs, not yet live-tested — see STORE_METADATA.md |

"Proven" means an actual run succeeded and its real step logs were
checked on a real GitHub Actions runner, not just a green checkmark. See
TESTING.md if you want to verify a workflow yourself before trusting it
with your own project.

## What this assumes

- You already have (or are creating) a Google Play Console developer
  account (a one-time $25 registration fee, separate from this
  template).
- Your Capacitor project already builds locally with `npx cap add
  android` (this template doesn't set up Capacitor itself — see
  [capacitorjs.com](https://capacitorjs.com) if you're starting from
  scratch).

## License

Personal-use license — for the person or team who purchased it, on your
own projects. Not for resale or redistribution. See LICENSE.md.

Questions before or after buying: localinfine@gmail.com
