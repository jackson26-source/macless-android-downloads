# Support

If a build fails, check **ANDROID.md**'s "Status" section first — it
covers the real errors this pipeline has already hit and fixed.

## Still stuck?

- **GitHub Discussions**: [jackson26-source/macless-downloads → Discussions](https://github.com/jackson26-source/macless-downloads/discussions) — the same support space used by the full Macless template (this is the same pipeline, just packaged without the iOS pieces). Ask a question, or search past ones first.
- **Email**: localinfine@gmail.com — include the failed run's log (Actions tab → the failed run → "Download log").

The 30-day money-back guarantee still applies if you genuinely can't get
a build out — see the site for details.
